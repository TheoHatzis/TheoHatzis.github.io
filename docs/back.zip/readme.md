# files

## All use 5000_cv.yaml

- theo_hatzis3.html, template = html_3.txt
- theo_hatzis.docx, template=py_short_resume_6.docx
- theo_hatzis.pdf, word conversion, save as or library


 